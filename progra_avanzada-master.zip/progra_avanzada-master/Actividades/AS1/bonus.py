from atracciones import AtraccionAdrenalinica, AtraccionFamiliar
import parametros as p


# Recuerda completar la herencia!
class AtraccionTerrorifica:

    def __init__(self):
        # COMPLETAR
        pass

    def iniciar_juego(self, personas):
        # COMPLETAR
        pass


# Recuerda completar la herencia!
class CasaEmbrujada:

    def iniciar_juego(self, personas):
        # COMPLETAR
        pass
