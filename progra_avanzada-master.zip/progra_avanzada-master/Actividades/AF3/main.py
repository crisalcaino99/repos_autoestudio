from dccabritas import DCCabritas


if __name__ == "__main__":
    cine = DCCabritas()
    cine.run()
