# NO DEBES MODIFICAR ESTE ARCHIVO

class Invitade:
    def __init__(self, nombre, edad, pase_movilidad, temperatura,
                 tos, dolor_cabeza, mail):
        self.nombre = nombre
        self.edad = edad
        self.mail = mail
        self.pase_movilidad = pase_movilidad
        self.temperatura = temperatura
        self.tos = tos
        self.dolor_cabeza = dolor_cabeza
