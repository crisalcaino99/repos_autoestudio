from menu_capitolio import menu_inicio

if __name__ == "__main__":
    menu_inicio()