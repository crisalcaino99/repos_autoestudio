# Mínimo de caracteres que debe tener el nombre de un nuevo usuario
MIN_CARACTERES = 1

# Máximo de caracteres que debe tener le nombre de un nuevo usuario
MAX_CARACTERES = 15
